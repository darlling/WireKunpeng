from main_ui import start

if __name__ == "__main__":
    start()
